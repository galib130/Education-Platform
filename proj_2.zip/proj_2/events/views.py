from django.shortcuts import render
from django.contrib.auth.mixins import (LoginRequiredMixin,PermissionRequiredMixin)
from django.contrib import messages
# Create your views here.
from django.urls import reverse
from django.views import generic
from events.models import Event,EventMember
from django.shortcuts import get_object_or_404
from . import models

class CreateEvent(LoginRequiredMixin,generic.CreateView):
    fields=('name','description')
    model =Event

class SingleEvent(generic.DetailView):
    model=Event

class ListEvents(generic.ListView):
    model=Event


class JoinEvent(LoginRequiredMixin,generic.RedirectView):
    def get_redirect_url(self,*args,**kwargs):
        return reverse('events:single',kwargs={'slug':self.kwargs.get('slug')})

    def get(self,request,*args,**kwargs):

        event=get_object_or_404(Event,slug=self.kwargs.get('slug'))

        try:
            EventMember.objects.create(user=self.request.user,event=event)

        except :
            messages.warning(self.request,'Warning already a member!')
        else:
            messages.success(self.request,'You are henceforth a member')
            
        return super().get(request,*args,**kwargs)


class LeaveEvent(LoginRequiredMixin,generic.RedirectView):
    def get_redirect_url(self,*args,**kwargs):
        return reverse('evnts:single',kwargs={'slug':self.kwargs.get('slug')})
    def get(self,request,*args,**kwargs):
        try:
            membership= models.EventMember.objects.filter(
            user=self.request.user,
            event__slug=self.kwargs.get('slug') ).get() 

        except models.EventMember.DoesNotExist:
            messages.warning(self.request,'Sorry you are not in this event!')

        else:
            membership.delete()
            messages.success(self.request,'You left the Event!') 

        return super().get(request,*args,**kwargs)
