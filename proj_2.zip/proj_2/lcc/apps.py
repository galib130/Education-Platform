from django.apps import AppConfig


class LccConfig(AppConfig):
    name = 'lcc'
